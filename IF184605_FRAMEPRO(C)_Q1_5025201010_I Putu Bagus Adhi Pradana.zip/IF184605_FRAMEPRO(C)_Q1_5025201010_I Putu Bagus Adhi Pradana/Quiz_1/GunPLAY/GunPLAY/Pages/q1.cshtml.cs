using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GunPLAY.Pages
{
    public class q1Model : PageModel
    {
        private readonly ILogger<q1Model> _logger;

        public q1Model(ILogger<q1Model> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
    }
}
