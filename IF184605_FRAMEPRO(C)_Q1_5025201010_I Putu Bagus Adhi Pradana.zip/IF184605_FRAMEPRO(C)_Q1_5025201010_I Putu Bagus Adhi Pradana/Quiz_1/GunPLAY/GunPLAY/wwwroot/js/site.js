﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.

    var pu = document.getElementById("popUP");
    var span = document.getElementsByClassName("exit")[0];

   function  infoR () {
        pu.style.display = "block";
    }

    span.onclick = function () {
        pu.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == pu) {
            pu.style.display = "none";
        }
    }


